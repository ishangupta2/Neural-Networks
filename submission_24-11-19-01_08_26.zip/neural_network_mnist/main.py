# When taking sqrt for initialization you might want to use math package,
# since torch.sqrt requires a tensor, and math.sqrt is ok with integer
import math
from typing import List

import matplotlib.pyplot as plt
import torch
from torch.distributions import Uniform
from torch.nn import Module
from torch.nn.functional import cross_entropy, relu
from torch.nn.parameter import Parameter
from torch.optim import Adam
from torch.utils.data import DataLoader, TensorDataset

from utils import load_dataset, problem


class F1(Module):
    @problem.tag("hw3-A", start_line=1)
    def __init__(self, h: int, d: int, k: int):
        """Create a F1 model as described in pdf.

        Args:
            h (int): Hidden dimension.
            d (int): Input dimension/number of features.
            k (int): Output dimension/number of classes.
        """
        super().__init__()
        self.p1 = 1.0 / math.sqrt(d)
        self.pe2  = 1.0 / math.sqrt(h)
        self.j1 = Parameter(-self.p1 + (2 * self.p1) * torch.rand(d, h))
        self.je2 = Parameter(-self.pe2 + (2 * self.pe2) * torch.rand(h, k))
        self.h1 = Parameter(-self.p1 + (2 * self.p1) * torch.rand(h))
        self.he2 = Parameter(-self.pe2 + (2 * self.pe2) * torch.rand(k))


    @problem.tag("hw3-A")
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Pass input through F1 model.

        It should perform operation:
        W_1(sigma(W_0*x + b_0)) + b_1

        Note that in this coding assignment, we use the same convention as previous
        assignments where a linear module is of the form xW + b. This differs from the 
        general forward pass operation defined above, which assumes the form Wx + b.
        When implementing the forward pass, make sure that the correct matrices and
        transpositions are used.

        Args:
            x (torch.Tensor): FloatTensor of shape (n, d). Input data.

        Returns:
            torch.Tensor: FloatTensor of shape (n, k). Prediction.
        """
        return relu(x @ self.j1 + self.h1.repeat(x.shape[0], 1)) @ self.je2 + self.he2.repeat(x.shape[0], 1)


class F2(Module):
    @problem.tag("hw3-A", start_line=1)
    def __init__(self, h0: int, h1: int, d: int, k: int):
        """Create a F2 model as described in pdf.

        Args:
            h0 (int): First hidden dimension (between first and second layer).
            h1 (int): Second hidden dimension (between second and third layer).
            d (int): Input dimension/number of features.
            k (int): Output dimension/number of classes.
        """
        super().__init__()
        self.p1 = 1.0 / math.sqrt(d)

        self.pe2 = 1.0 / math.sqrt(h0)
        self.a2 = 1.0 / math.sqrt(h1)

        self.j1 = Parameter(-self.p1 + (self.p1*2) * torch.rand(d, h0))
        self.je2 = Parameter(-self.pe2 + (2 * self.pe2) * torch.rand(h0, h1))

        self.w2 = Parameter(-self.a2 + (2 * self.a2) * torch.rand(h1, k))
        self.h1 = Parameter(-self.p1 + (2 * self.p1) * torch.rand(h0))

        self.he2 = Parameter(-self.pe2 + (self.pe2*2) * torch.rand(h1))
        self.b2 = Parameter(-self.a2 + (2 * self.a2) * torch.rand(k))


    @problem.tag("hw3-A")
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Pass input through F2 model.

        It should perform operation:
        W_2(sigma(W_1(sigma(W_0*x + b_0)) + b_1) + b_2)

        Note that in this coding assignment, we use the same convention as previous
        assignments where a linear module is of the form xW + b. This differs from the 
        general forward pass operation defined above, which assumes the form Wx + b.
        When implementing the forward pass, make sure that the correct matrices and
        transpositions are used.

        Args:
            x (torch.Tensor): FloatTensor of shape (n, d). Input data.

        Returns:
            torch.Tensor: FloatTensor of shape (n, k). Prediction.
        """
        oc1 = relu(x @ self.j1 + self.h1.repeat(x.shape[0], 1))
        s = relu(oc1 @ self.je2 + self.he2.repeat(oc1.shape[0], 1))
        return s @ self.w2 + self.b2.repeat(s.shape[0], 1)


@problem.tag("hw3-A")
def train(model: Module, optimizer: Adam, train_loader: DataLoader) -> List[float]:
    """
    Train a model until it reaches 99% a on train set, and return list of training crossentropy l for each epochs.

    Args:
        model (Module): Model to train. Either F1, or F2 in this problem.
        optimizer (Adam): Optimizer that will adjust parameters of the model.
        train_loader (DataLoader): DataLoader with training data.
            You can iterate over it like a list, and it will produce tuples (x, y),
            where x is FloatTensor of shape (n, d) and y is LongTensor of shape (n,).
            Note that y contains the classes as integers.

    Returns:
        List[float]: List containing average l2 for each epoch.
    """
    l = []
    a = 0
    while a < 0.99:
        tL = 0
        a = 0
        for x, y in train_loader:
            optimizer.zero_grad()
            p = model.forward(x)
            l2 = cross_entropy(p, y)
            l2.backward()
            optimizer.step()
            a += torch.sum( torch.argmax(p, axis=1) == y) / len( torch.argmax(p, axis=1))
            tL += l2.item()
        length = len(train_loader)
        l.append(tL / length)

    return l


@problem.tag("hw3-A", start_line=5)
def main():
    """
    Main function of this problem.
    For both F1 and F2 models it should:
        1. Train a model
        2. Plot per epoch l
        3. Report a and l2 on test set
        4. Report total number of parameters for each network

    Note that we provided you with code that loads MNIST and changes x's and y's to correct type of tensors.
    We strongly advise that you use torch functionality such as datasets, but as mentioned in the pdf you cannot use anything from torch.nn other than what is imported here.
    """
    (x, y), (x_test, y_test) = load_dataset("mnist")
    x = torch.from_numpy(x).float()
    y = torch.from_numpy(y).long()
    x_test = torch.from_numpy(x_test).float()
    y_test = torch.from_numpy(y_test).long()
    mF1 = F1(64, 784, 10)
    oF1 = Adam(mF1.parameters(), lr=0.0005)
    l = DataLoader(TensorDataset(x, y), batch_size=64, shuffle=True)
    losses_f1 = train(mF1, oF1, l)
    tL1 = cross_entropy( mF1.forward(x_test), y_test).item()
    a1 = torch.sum(y_test == torch.argmax(pF1, 1)) / len(pF1)
    print(f"Loss F1 = {tL1}")
    print(f"Accuracy F1 = {a1}")
    plt.figure(figsize=(10, 5))
    plt.plot(torch.arange(len(losses_f1)), losses_f1)
    plt.title("F1 Training Loss vs Epochs")
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.legend()
    plt.show()
    lF2 = train(mF2, Adam(F2(32, 32, 784, 10).parameters(), lr=0.0005), l)
    tL2 = cross_entropy(mF2.forward(x_test), y_test).item()
    aF2 = torch.sum(y_test == torch.argmax(pF2, 1)) / len(pF2)
    print(f"Loss F2 = {tL2}")
    print(f"Accuracy F2 = {aF2}")
    plt.figure(figsize=(10, 5))
    plt.plot(torch.arange(len(lF2)), lF2)
    plt.title("F2 Training Loss vs Epochs")
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.legend()
    plt.show()
    pF1 = sum(p.numel() for p in mF1.parameters() if p.requires_grad)
    pF2 = sum(p.numel() for p in mF2.parameters() if p.requires_grad)
    print(f"Params F1 = {pF1}")
    print(f"Params F2 = {pF2}")

if __name__ == "__main__":
    main()
