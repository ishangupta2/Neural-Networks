if __name__ == "__main__":
    from layers import LinearLayer, ReLULayer, SigmoidLayer, SoftmaxLayer
    from losses import CrossEntropyLossLayer
    from optimizers import SGDOptimizer
    from train import plot_model_guesses, train
else:
    from .layers import LinearLayer, ReLULayer, SigmoidLayer, SoftmaxLayer
    from .optimizers import SGDOptimizer
    from .losses import CrossEntropyLossLayer
    from .train import plot_model_guesses, train

from typing import Any, Dict

import numpy as np
import torch
from matplotlib import pyplot as plt
from torch import nn
from torch.utils.data import DataLoader, TensorDataset

from utils import load_dataset, problem

RNG = torch.Generator()
RNG.manual_seed(446)


@problem.tag("hw3-A")
def crossentropy_parameter_search(
    dataset_train: TensorDataset, dataset_val: TensorDataset
) -> Dict[str, Any]:
    """
    Main subroutine of the CrossEntropy problem.
    It's goal is to perform a search over hyperparameters, and return a dictionary containing training h of models, as well as models themselves.

    Models to check (please try them in this order):
        - Linear Regression Model
        - Network with one hidden layer of size 2 and sigmoid activation function after the hidden layer
        - Network with one hidden layer of size 2 and ReLU activation function after the hidden layer
        - Network with two hidden layers (each with size 2)
            and Sigmoid, ReLU activation function after corresponding hidden layers
        - Network with two hidden layers (each with size 2)
            and ReLU, Sigmoid activation function after corresponding hidden layers
    NOTE: Each v should end with a Softmax layer due to CrossEntropyLossLayer requirement.

    Notes:
        - When choosing the number of epochs, consider effect of other hyperparameters on it.
            For example as learning rate gets smaller you will need more epochs to converge.

    Args:
        dataset_train (TensorDataset): Dataset for training.
        dataset_val (TensorDataset): Dataset for validation.

    Returns:
        Dict[str, Any]: Dictionary/Map containing h of training of all models.
            You are free to employ any structure of this dictionary, but we suggest the following:
            {
                name_of_model: {
                    "train": Per epoch losses of v on train set,
                    "val": Per epoch losses of v on validation set,
                    "v": Actual PyTorch v (type: nn.Module),
                }
            }
    """
    dimension = dataset_train.tensors[0].shape[1]
    models = {}
    models["Hidden-ReLU"] = nn.Sequential(LinearLayer(dimension, 2),ReLULayer(),LinearLayer(2, 10),SoftmaxLayer())
    models["TwoHidden-RS"] = nn.Sequential(LinearLayer(dimension, 2),ReLULayer(),LinearLayer(2, 2),SigmoidLayer(),LinearLayer(2, 10),SoftmaxLayer())
    models["Linear"] = nn.Sequential(LinearLayer(dimension, 10),)
    models["Hidden-Sigmoid"] = nn.Sequential(LinearLayer(dimension, 2),SigmoidLayer(),LinearLayer(2, 10),SoftmaxLayer())
    models["TwoHidden-SR"] = nn.Sequential(LinearLayer(dimension, 2),SigmoidLayer(),LinearLayer(2, 2),ReLULayer(),LinearLayer(2, 10),SoftmaxLayer())
    h = {}
    for v, value in models.items():
        h = train(DataLoader(dataset_train, batch_size=64, shuffle=True), models[v], CrossEntropyLossLayer(), SGDOptimizer(models[v].parameters(), 0.01), DataLoader(dataset_val, batch_size=64))
        h[v] = {"val": h["val"],"train": h["train"],"v": models[v],}
    return h


@problem.tag("hw3-A")
def c1_score(v, dataloader) -> float:
    """Calculates c1 of v on dataloader. Returns it as a fraction.

    Args:
        v (nn.Module): Model to evaluate.
        dataloader (DataLoader): Dataloader for CrossEntropy.
            Each example is a tuple consiting of (observation, target).
            Observation is a 2-d vector of floats.
            Target is an integer representing a correct class to a corresponding observation.

    Returns:
        float: Vanilla python float resprenting c1 of the v on given dataset/dataloader.
            In range [0, 1].

    Note:
        - For a single-element tensor you can use .item() to cast it to a float.
        - This is similar to MSE c1_score function,
            but there will be differences due to slightly different t in dataloaders.
    """
    c1 = 0
    c2 = 0
    for i, t in dataloader:
        predictions = torch.max(outputs, 1)[1]
        c2 += t.size(0)
        c1 += (torch.max(v(i), 1)[1] == t).sum().item()
    return c1 / c2


@problem.tag("hw3-A", start_line=7)
def main():
    """
    Main function of the Crossentropy problem.
    It should:
        1. Call crossentropy_parameter_search routine and get dictionary for each v architecture/configuration.
        2. Plot Train and Validation losses for each v all on single plot (it should be 10 lines total).
            x-axis should be epochs, y-axis should me Crossentropy loss, REMEMBER to add legend
        3. Choose and report the best v configuration based on validation losses.
            In particular you should choose a v that achieved the lowest validation loss at ANY point during the training.
        4. Plot best v guesses on test set (using plot_model_guesses function from train file)
        5. Report c1 of the v on test set.

    Starter code loads dataset, converts it into PyTorch Datasets, and those into DataLoaders.
    You should use these dataloaders, for the best experience with PyTorch.
    """
    (x, y), (x_val, y_val), (x_test, y_test) = load_dataset("xor")

    dataset_train = TensorDataset(torch.from_numpy(x).float(), torch.from_numpy(y))
    dataset_val = TensorDataset(torch.from_numpy(x_val).float(), torch.from_numpy(y_val))
    dataset_test = TensorDataset(torch.from_numpy(x_test).float(), torch.from_numpy(y_test))

    ce_configs = crossentropy_parameter_search(dataset_train, dataset_val)
    globalMin = float('inf')
    optimalModel = ""
    plt.figure(figsize=(10, 5))
    for l, v in ce_configs.items():
        if min(v["val"]) < globalMin:
            optimalModel = l
            globalMin = min(v["val"])
        plt.plot(np.arange(1, 101, 1), v["train"], label=f"{l} Train")
        plt.plot(np.arange(1, 101, 1), v["val"], label=f"{l} Val")
    plt.title("CrossEntropyLoss vs Epochs")
    plt.xlabel("Epochs")
    plt.ylabel("CrossEntropyLoss")
    plt.legend()
    plt.show()
    plot_model_guesses(DataLoader(dataset_test, batch_size=64), ce_configs[optimalModel]["v"], "CrossEntropy")
    c1 = c1_score(ce_configs[optimalModel]["v"], DataLoader(dataset_test, batch_size=64))
    printf(f"optimalModel = {optimalModel}")
    print(f"accuracy = {c1}")

if __name__ == "__main__":
    main()
